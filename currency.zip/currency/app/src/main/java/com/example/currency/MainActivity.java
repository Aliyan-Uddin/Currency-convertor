package com.example.currency;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.currency.R;

public class MainActivity extends AppCompatActivity {

    private EditText amountEditText;
    private Spinner fromCurrencySpinner, toCurrencySpinner;
    private Button convertButton;
    private TextView resultTextView;

    // Currency conversion rates
    private final double usdToPakRate = 278.81;
    private final double usdToIndRate = 86.14;
    private final double usdToPoundRate = 0.82;

    private final double pakToUsdRate = 0.0035;
    private final double pakToIndRate = 0.30;
    private final double pakToPoundRate = 0.0029;

    private final double indToUsdRate = 0.011;
    private final double indToPakRate = 3.23;
    private final double indToPoundRate = 0.0095;

    private final double poundToUsdRate = 1.21;
    private final double poundToIndRate = 105.04;
    private final double poundToPakRate = 340.01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        amountEditText = findViewById(R.id.amountEditText);
        fromCurrencySpinner = findViewById(R.id.fromCurrencySpinner);
        toCurrencySpinner = findViewById(R.id.toCurrencySpinner);
        convertButton = findViewById(R.id.convertButton);
        resultTextView = findViewById(R.id.resultTextView);

        // Set up spinners with currency options
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.currency_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromCurrencySpinner.setAdapter(adapter);
        toCurrencySpinner.setAdapter(adapter);

        // Set up button click listener for conversion
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertCurrency();
            }
        });
    }

    private void convertCurrency() {
        // Get input amount
        String amountStr = amountEditText.getText().toString();
        if (amountStr.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter an amount", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);

        // Get selected currencies
        String fromCurrency = fromCurrencySpinner.getSelectedItem().toString();
        String toCurrency = toCurrencySpinner.getSelectedItem().toString();

        double convertedAmount = 0.0;

        // Perform conversion based on selected currencies
        if (fromCurrency.equals("USD")) {
            if (toCurrency.equals("PKR")) {
                convertedAmount = amount * usdToPakRate;
            } else if (toCurrency.equals("INR")) {
                convertedAmount = amount * usdToIndRate;
            } else if (toCurrency.equals("GBP")) {
                convertedAmount = amount * usdToPoundRate;
            }
        } else if (fromCurrency.equals("PKR")) {
            if (toCurrency.equals("USD")) {
                convertedAmount = amount * pakToUsdRate;
            } else if (toCurrency.equals("INR")) {
                convertedAmount = amount * pakToIndRate;
            } else if (toCurrency.equals("GBP")) {
                convertedAmount = amount * pakToPoundRate;
            }
        } else if (fromCurrency.equals("INR")) {
            if (toCurrency.equals("USD")) {
                convertedAmount = amount * indToUsdRate;
            } else if (toCurrency.equals("PKR")) {
                convertedAmount = amount * indToPakRate;
            } else if (toCurrency.equals("GBP")) {
                convertedAmount = amount * indToPoundRate;
            }
        } else if (fromCurrency.equals("GBP")) {
            if (toCurrency.equals("USD")) {
                convertedAmount = amount * poundToUsdRate;
            } else if (toCurrency.equals("INR")) {
                convertedAmount = amount * poundToIndRate;
            } else if (toCurrency.equals("PKR")) {
                convertedAmount = amount * poundToPakRate;
            }
        }

        // Display result
        String resultText = "Converted Amount: ";
        if (toCurrency.equals("USD")) {
            resultText += "$" + String.format("%.2f", convertedAmount);
        } else if (toCurrency.equals("PKR")) {
            resultText += String.format("%.2f", convertedAmount) + " /-PKR";
        } else if (toCurrency.equals("GBP")) {
            resultText += "GBP " + String.format("%.2f", convertedAmount);
        } else if (toCurrency.equals("INR")) {
            resultText += String.format("%.2f", convertedAmount) + " /-INR";
        }

        resultTextView.setText(resultText);
    }
}
